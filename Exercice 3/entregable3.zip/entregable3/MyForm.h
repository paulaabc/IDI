#include "ui_MyForm.h"

class MyForm:public QWidget {
    public:
    MyForm(QWidget *parent=0);
    private:
    Ui::MyForm ui;
};